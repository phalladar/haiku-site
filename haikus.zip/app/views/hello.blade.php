<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laravel PHP Framework</title>
	<style>

	</style>
</head>
<body>
	<h1>Hello, {{{ $name }}}.</h1>
</body>
</html>
