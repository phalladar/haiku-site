<?php

Class Haiku extends Eloquent {
	protected $table = 'haiku';
}